package Consola;

public class Alfil extends Ficha{

	public Alfil(int pos1, int pos2) {
		super(pos1, pos2);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int movimientoPos() {
		// TODO Auto-generated method stub
		return 0;
	}

}
