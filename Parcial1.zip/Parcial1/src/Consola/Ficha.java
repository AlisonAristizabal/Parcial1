package Consola;

public abstract class Ficha {
	int posicionc;
	int posicionf;
	public Ficha(int pos1, int pos2) {
		this.posicionc = pos1;
		this.posicionf = pos2;
	}
	
	public abstract int movimientoPos();
}
