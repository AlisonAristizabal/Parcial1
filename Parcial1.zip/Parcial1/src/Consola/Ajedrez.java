package Consola;


public class Ajedrez {
	String matriz[][]= new String[8][8];

	public String[][] getMatriz() {
		return matriz;
	}

	public void setMatriz(String[][] matriz) {
		this.matriz = matriz;
	}

}
