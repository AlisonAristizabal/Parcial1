package Consola;

public class Peon extends Ficha{

	public Peon(int pos1, int pos2) {
		super(pos1, pos2);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int movimientoPos() {
		// TODO Auto-generated method stub
		int par = this.posicionc+this.posicionf;
		if (par%2 == 0) {
			this.posicionf = this.posicionf+2;
		}else {
			this.posicionf = this.posicionf+1;
		}
		return 0;
	}

	
}
